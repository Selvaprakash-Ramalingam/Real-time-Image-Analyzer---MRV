# PRD — AgriSkill Navigator (Google Cloud–Aligned)

**Prepared By:** Selvaprakash Ramalingam  
**Date:** August 2025

[See executive summary, goals, architecture, and features exactly as per hackathon-ready brief, aligned to Google Cloud services: Vertex AI, BigQuery ML, Dialogflow CX, Firestore, Cloud Run, Neo4j on GCP.]

This repository contains the scaffold to realize that PRD quickly.
