# Real-time Image Analyzer — MRV Enhanced

This build keeps only the Real-time Image Analyzer and adds a minimal MRV layer:
- Geolocation capture
- Index summary (mean/min/max) & sharpness metric
- Save records to FastAPI backend (`/records`)
- MRV Dashboard to view & export CSV

## Run
Frontend:
```
cd frontend/web
npm install
npm run dev
```
Backend:
```
cd backend
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```
Optionally set `VITE_API_URL` in `frontend/web/.env` to point to your backend URL.
